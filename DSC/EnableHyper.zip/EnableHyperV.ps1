configuration EnableHyperV 
{ 
 Import-DscResource -ModuleName 'PSDesiredStateConfiguration'

 Node Hypervisor{
  WindowsFeature Hyper-V {
   Ensure = 'Present'
   Name = "Hyper-V"
   IncludeAllSubFeature = $true
  }
 }
    
}