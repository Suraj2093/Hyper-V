Configuration Hypervisor {

Import-DscResource -ModuleName 'xPSDesiredStateConfiguration', 'xHyper-V'
Node localhost{

WindowsFeature Hyper-V {
Ensure = 'Present'
Name = "Hyper-V"
IncludeAllSubFeature = $true
}

}

}

Hypervisor