Configuration Hypervisor {

Import-DscResource -ModuleName 'PSDesiredStateConfiguration', 'xHyper-V'
Node localhost{

WindowsFeature Hyper-V {
Ensure = 'Present'
Name = "Hyper-V"
IncludeAllSubFeature = $true
}

}

}

Hypervisor