Configuration Hypervisor {

Import-DscResource -ModuleName 'PSDesiredStateConfiguration', 'xRemoteDesktopAdmin', 'xTimezone','xHyper-V', 'xComputerManagement'

Node localhost{

WindowsFeature Hyper-V {
Ensure = 'Present'
Name = "Hyper-V"
IncludeAllSubFeature = $true
}

WindowsFeature Failover-Clustering {
Ensure = 'Present'
Name ='Failover-Clustering'
}
        
WindowsFeature  Multipath-IO {
Ensure = 'Present'
Name=' Multipath-IO'
IncludeAllSubFeature = $true
} 

WindowsFeature RSAT-Shielded-VM-Tools{
Ensure = 'Present'
Name='RSAT-Shielded-VM-Tools'
IncludeAllSubFeature = $true
}

WindowsFeature RSAT-Clustering-Powershell{
Ensure = 'Present'
Name='RSAT-Clustering-Powershell'
IncludeAllSubFeature = $true
}

WindowsFeature Hyper-V-PowerShell{
Ensure = 'Present'
Name='Hyper-V-PowerShell'
IncludeAllSubFeature = $true
}


#Base OS Settings
        {
xUAC UAC{
Setting = "NotifyChanges"         
}
 
xTimeZone ServerTime{
TimeZone = "Eastern Standard Time"
}
 
xRemoteDesktopAdmin RemoteDesktopSettings {
Ensure = 'Present'
UserAuthentication = 'secure'
}
 
        }

#HyperVisor Host Settings {        
#VM Folder Directory 
    File VMs {
    Ensure = 'Present'
    Type = 'Directory'
     DestinationPath = "$($env:SystemDrive)\VMs"
}


#VM Host Switch 
    xVMSwitch InternalVSwitch {
        DependsOn = '[WindowsFeature]Hyper-V'
        Name = 'IntvSwitch'
        Ensure = 'Present'
        Type = 'Internal'
}
}


}

Hypervisor