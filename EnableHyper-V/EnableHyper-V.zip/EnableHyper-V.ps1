configuration EnableHyper-V 
{ 
    
Install-WindowsFeature Hyper-V -IncludeManagementTools �Restart
    
}